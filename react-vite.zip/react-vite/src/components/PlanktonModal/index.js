import PlanktonModal from './PlanktonModal';

export default PlanktonModal;
