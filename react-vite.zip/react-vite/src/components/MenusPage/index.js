import MenusPage from "./MenusPage"

export default MenusPage;