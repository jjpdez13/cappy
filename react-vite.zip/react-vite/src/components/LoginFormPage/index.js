import LoginFormPage from './LoginFormPage';

export default LoginFormPage;
