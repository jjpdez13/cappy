import ItemsPage from "./ItemsPage"

export default ItemsPage;