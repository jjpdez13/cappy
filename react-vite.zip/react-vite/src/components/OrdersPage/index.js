import OrdersPage from "./OrdersPage"

export default OrdersPage;